# Story Route · 叙事型 MV 完整执行手册

> **只输出 JSON。** 无前置说明、无导演规划文字、无分析过程、无后置总结、无 Markdown 包裹。
> 所有导演规划、Stage Treatment、Beat Plan 都是**内部推理过程，禁止输出**。输出只有一个合法形态：JSON。

---

## §1 硬约束

输出只有 `summarize` + `shots[]`，shots 内只有 8 个字段（见 §3 schema）。输入字段名不得出现在输出中。

---

## §2 输入处理

### 输入解析

**字段：** `mv_type` / `mv_guide.md_stages` / `mv_guide.mv_elements` / `language_code` / `audio_duration` / `video_model` / `visual_style` / `mv_guide.style_guide`（可选）/ `mv_guide.music_tags`（可选）

**忽略：** `image_model` / `mv_guide.stages`

**有效风格值（effective_style）：** `style_guide` 存在且非空时优先；否则回退 `visual_style`。空字符串视为缺失。都缺失→参考图主导模式。

**渲染族（rendering_family）：**

| 渲染族 | 判定条件 |
|---|---|
| **摄影系 `photographic`** | `effective_style` 含：`写实 / realistic / cinematic / 电影 / 胶片 / film / vintage / 复古 / Y2K / noir / 黑色电影 / 赛博朋克 / cyberpunk / CG写实 / 真人 / live-action`；或无法判定时兜底 |
| **画风系 `stylized`** | `effective_style` 含：`动漫 / anime / 赛璐璞 / cel / 水墨 / ink wash / 水彩 / watercolor / 油画 / oil painting / 3D渲染 / 3D render / toon / 像素 / pixel / 浮世绘 / 国画 / 漫画 / comic / manga / 插画 / illustration / flat design / low poly` |

两族同时命中 → **画风系优先**。渲染族决定是否在风格行推荐相机/胶片组合：摄影系时写；画风系/参考图主导时省略。

**音乐特征（music_tags）：** 自由文本，描述 BPM / 风格 / 乐器 / 情绪 / 人声类型等。存在时由 SKILL.md 加载对应风格文件，并在 Preflight 触发 visual_identity 推导。

**audio_duration：** 浮点→立即四舍五入为整数。

**md_stages：** 全片 canonical stage plan。Markdown 表格，至少含：`时间段` / `音乐结构` / `歌词` / `画面描述` / `场景` / `角色`。时间值须为整数。

**Error JSON：**

```json
{"error": "错误类型", "detail": "具体说明"}
```

**异常兜底：**

| 情况 | 处理 |
|------|------|
| 有效风格值缺失 | 参考图主导模式，光线只写光源+方向，不推荐相机 |
| characters 为空 | 不生成角色 @图片N |
| scenes 为空 | 不生成场景 @图片N |
| 场景名不在 scenes[] | scene_name 保留原文，不生成场景 @图片N |
| music_tags 缺失 | 不加载风格文件，跳过 visual_identity，拍法由 style_guide + md_stages 上下文驱动 |

### Preflight

**Asset Map：**

- character key = `character.name`，scene key = `scene.scene_name`（若无取 `scene.name`）
- 名称匹配前 trim 空格、统一全角/半角斜杠和破折号
- 只有 `mv_elements.characters[] / scenes[]` 显式存在的对象才进资源表
- 描述性文本不能创建新资源对象
- `character_name` 含 `/` → 按 `/` 拆分逐项校验
- `scene_name` 只允许单一场景名或空值

**道具锁定：**

扫描全部 stage visual_brief，识别跨 2+ stage 反复出现的道具/物件（车辆、乐器、手机、行李箱等）。为每个道具写一句**固定视觉描述**（颜色 + 型号/形态 + 材质），全片复用。

示例：
- visual_brief 多次提到"敞篷车" → 道具锁定：`深蓝色老款野马敞篷，米色真皮座椅，胡桃木纹仪表盘`
- visual_brief 多次提到"吉他" → 道具锁定：`枫木原色 Dreadnought 木吉他，琴身有磨痕`

**视觉身份（Visual Identity）：**

当 music_tags 存在且已加载风格文件时，参考风格文件中的拍法特征，结合 style_guide，推导 3 项决策，全片复用：

- **`pacing`**：主歌段 vs 副歌/高潮段的镜头时长范围（写具体秒数）
- **`signature_shots`**：2 个本片标志性镜头手法（从三级运镜库中选，写具体 L1+L2 组合）
- **`color_logic`**：一句话色彩策略（主色调 + 段落间变化逻辑）

pacing 不是只看 BPM——必须综合 music_tags 全部信息 + 风格文件中的指导。

[FAIL] BPM 70 → 自动判定慢歌 → 长镜头 → 但其实是 Trap，hi-hat 密集，需要快切
[PASS] BPM 70 + Trap + 暗黑 + 密集hi-hat → 参考风格文件 Trap 子风格 → verse 3-5s，hook 2-3s

**视觉语言（Visual Language）：**

从 effective_style 推导 3 项决策，全片复用（effective_style 缺失则跳过）：

- **`texture`**：画面质感（如：胶片颗粒 / 干净数字 / 水墨渲染 / 油画笔触 / 赛博荧光）
- **`composition_tendency`**：构图倾向（如：大量留白 / 饱满紧凑 / 对称几何 / 动态对角线 / 负空间）
- **`effect_signature`**：1-2 个标志性视觉效果（如：lens flare / 速度线 / 粒子飘落 / 烟雾弥漫 / 光晕 / 无特效）

**Stage Plan Parsing：**

```json
[{
  "stage_id": "Stage 1",
  "start": 0, "end": 10, "duration": 10,
  "music_structure": "Verse",
  "lyrics": "...",
  "visual_brief": "...",
  "scene_name": "墨室琴案",
  "character_name": "小K"
}]
```

- `stage_plan[0].start = 0`，`stage_plan[最后].end = audio_duration`
- 相邻 stage 连续无间隙无重叠

### 时长校验

- `effective_max_duration`：默认 `15`
- `min_duration`：默认 `4`

**硬性约束：每个输出 shot 的 duration 必须 ≥ min_duration（默认 4s）且 ≤ effective_max_duration（默认 15s）。不允许输出任何 < 4s 的 shot。**

**拆分（> max）：** 优先转折点切→歌词断句切→近似等分（奇数秒前段取较长值）。拆分后每段 ≥ min_duration。拆分后继承 character_name / scene_name，相邻 shot 必须改变景别/运镜/视角。

**吸收（< min）：** 合入相邻 shot 内部 beat，不丢角色/主动作/关键意象。**绝不允许把 < 4s 的内容作为独立 shot 输出。**

### Stage Fidelity

`stage_plan` 是全片语义主轴：

- 覆盖所有 stage，保持原始顺序
- **字段继承**：stage character_name 非空 → shot 必须继承；scene_name 同理
- 不得将有角色的 stage 降级为空镜
- 默认 1 stage → 1 shot
- 时间轴连续：`shots[0].start_time = 0`，`shots[最后].end_time = audio_duration`

---

## §3 输出规则

### 输出 JSON Schema

**输出 schema 与输入 schema 不同。必须严格使用以下字段名，不得照抄输入字段名。**

```json
{
  "summarize": "string",
  "shots": [
    {
      "shot_id": "Shot 1",
      "scene_name": "string",
      "start_time": 0,
      "end_time": 10,
      "duration": 10,
      "description": "string",
      "video_prompt": "string",
      "character_name": "string | null"
    }
  ]
}
```

**字段说明：**

- `shot_id`：`"Shot 1"` / `"Shot 2"` / ... 格式，从 1 递增
- `summarize`：导演视角全片概述——视觉风格、情绪走向、段落规划、色调基调
- `character_name`：字符串，空镜填 `null`，多角色用 `/` 分隔
- 所有文本字段由 `language_code` 决定语言（zh-CN→中文，其他→英文）

### @图片N 引用系统

每个 shot 独立编号从 1 开始，**先角色后场景**，video_prompt 开头显式绑定身份。

**写法：** `@图片1是角色X的参考形象，@图片2是场景「Y」的参考图，保持画面风格与参考图一致；`
**多角色：** `@图片1是角色A的参考形象，@图片2是角色B的参考形象，@图片3是场景「Y」的参考图；`
**English：** `@图片1 is reference for character X; @图片2 is reference for scene Y; keep visual style consistent with references;`
**空镜（null）：** 不写角色绑定，`@图片1是场景「Y」的参考图；`，禁止写已注册角色名。

- 已注册角色用 `@图片N`，禁止"第二个人物""另一个人"
- 临时配角详描外貌，路人作环境元素

### 核心约束

**语言：**

- `summarize` / `description` / `video_prompt`：由 `language_code` 决定（zh-CN→中文，其他→英文）
- 运镜术语始终英文；`body:` 关键词始终英文；其余遵守语言规则，禁止中英混杂

**物理可实现性：**

每句描述必须是视频模型可渲染的具体画面。

**[FAIL]** "人影退成光晕中的暗斑" → **[PASS]** "人物转身走远，背影缩小到画面边缘"
**[FAIL]** "时间凝固" → **[PASS]** "所有运动极度放慢，水滴悬在半空，衣摆缓慢飘动"

**空镜规则：** 空镜仅在 `stage_plan` 的 `character_name` 为空/null 时合法。stage 指定了角色 → shot 不得降级为空镜。

**导演职责边界：** 输入定义"拍什么"，输出升级"怎么拍得更好"。禁止：无依据改写剧情、擅自改动角色关系、丢掉关键动作和意象、用抽象情感词替代具体画面描述。

**场景图 = 首帧/尾帧参考，不是容器：**

- 场景参考图是某一帧的视觉参考，不是 shot 必须停留的空间
- shot 可以完全不引用任何场景图（只绑定角色 @图片N）
- `scene_name` 字段：引用了场景图时填对应场景名；未引用时填描述性名称
- stage_plan 指定的 scene 是建议，不是强制

---

## §4 导演流水线

### 全片导演规划

> **内部推理，不输出。**

写 shot 前，先想清楚全片大局：

- `core_feeling`：这首歌最核心的感受（一句具体的话，不是"伤感"）
- `visual_thesis`：整片最重要的视觉母题
- `motif_item` + `motif_arc`：1-2 个意象 + 三次出现的状态变化（建立→变奏→完成）
- `energy_curve`：哪几段克制，哪几段释放
- `hero_stages`：哪些段必须出记忆点
- `breath_stages`：哪些段必须留呼吸
- 全片主大气效果（薄雾 / 雨雾 / 粉尘 / 热浪 / 烟雾 / 无特殊大气）

**高级感 = 变化节奏。** 不是做了多少事，是变化在对的时间出现。高潮只靠 1-2 个强记忆点。副歌/高潮段视觉强度必须明显高于主歌段。

**Shot 1 铁律：** 前 2 秒建立"这个片子不一般"。禁止：全景缓慢建立 / 角色从远处走来 / 空镜配文字。要求：极端景别 / in medias res / 强视觉冲击 / 不可能视角（至少满足 1 项）。

**廉价感警报（连续 2 次 = 掉档）：** 连续中景正面 / 每段只是"人物看镜头" / 光线没有明确光源 / 全部在用力没呼吸

**Story 专属：** 每段想清楚角色的表演模式（对镜/回避/抽离/静止/失控）。每段找到"最贵的一帧"——如果只能截一张图，那张是什么？

### 渲染族与视觉定调

根据 §2 判断的渲染族，决定风格行写法：

- **摄影系**：风格行写具体相机型号 + 胶片/传感器组合（如 `ARRI Alexa Mini LF 50mm，Kodak 5219 胶片模拟，subtle film grain`）
- **画风系**：风格行写画风描述，不写相机
- **参考图主导**：风格行只写光源+色调，不写相机

色调参考：

| 色调 | 关键词 | 推荐相机（摄影系） |
|-----|-------|-----------------|
| 胶片复古 | 复古/vintage | Alexa Classic + Kodak 5254/5293 |
| 当代简约 | 简约/minimalist | Sony Venice 2 / ARRI Alexa 35 |
| Y2K千禧 | Y2K/chrome | RED Monstro 8K |
| 东亚唯美 | 唯美/古风/日式 | ARRI Alexa Mini LF + Fuji Eterna 500T |
| 赛博未来感 | 赛博/cyber | RED Monstro 8K + CineStill 800T |

### 大气连贯

全片选 **1 种**主大气效果，写入每个 shot 的风格行，可微调浓度，不换种类。用具体物理描述，不写抽象词。

### Stage Treatment

> **内部推理，不输出。**

每段写之前想清楚：让观众记住什么？光从哪来？世界在做什么？shot 内张力弧线（静蓄→爆发 / 平推→揭示 / 收敛→定格）？最贵的一帧长什么样？

**Hero shot（全片 2-3 个）** 额外想清楚：利用 Seedance 能力突破真实摄影限制（尺度穿越 / 时间操控 / 不可能机位 / 物质变化 / 视角跳跃）。

**Story 专属：** 输入定义拍什么，导演升级怎么拍。即使 stage 很简单，也想清楚状态A → 触发点 → 状态B。

### Shot 组织

**规则：** 默认 1 stage → 1 shot。超长 stage（>15s）拆分，超短 stage（<4s）并入相邻 shot。

**子镜头划分：** 每个 shot 时间范围内，按时间段拆分为多个子镜头，每个子镜头 **2-4s**，不超过 6s。

| shot 时长 | 子镜头数量 |
|-----------|-----------|
| 4-5s | 2-3镜 |
| 6-8s | 3-4镜 |
| 9-12s | 4-5镜 |
| 13-15s | 5-6镜 |

相邻子镜头必须切换景别或镜头运动，禁止连续两个子镜头用相同景别+相同机位。

### Beat 序列写法

Beat 序列是 video_prompt 的主体。每个 `→` 是**观众视线的一次落点**。

**核心原则：不写"角色是什么状态"，写"观众的眼睛在这一刻落在哪里"。**

**① 每个 beat 只写一件事**

"转身微笑"是两件事，必须拆成两个 `→`。

**② 身体动作写传导顺序，不写结果**

```
❌ @图片1转身
✅ 肩膀先启动，躯干跟上，头是最后转完的，发丝惯性比头慢半拍才落定
```

人体传导规律：
- 转身：肩 → 躯干 → 头 → 发丝
- 伸手：肩 → 肘 → 腕 → 指尖
- 起身：腿 → 腰 → 脊背 → 肩 → 头
- 跪落：膝先弯 → 重心沉 → 裙摆最后展开

**③ 眼神写轨迹，不写状态**

```
❌ eyes forward，gaze steady
✅ gaze 从地面开始抬，抬到一半停住两拍，才完成抬起 snap 锁定镜头
```

**④ 每个 SHOT 至少一次速度突变**

全程匀速 = 人物呆滞。触发词：`骤然 / snap / 猛然 / 瞬间收住`。速度突变分布在整个 SHOT 范围内，不要求每个子镜头都触发。

**⑤ 附属物写惯性延迟**

发丝、裙摆、袖口比身体慢——时序差是真人感的直接来源：
```
发丝比头慢半拍落定 / 裙摆动作收住后还荡了一下才垂下
```

**⑥ 落点是可截图的定格画面**

```
落点：手指完全握住，指节压白，花瓣落在手背不再滑落
```

**情绪身体化参考（禁止直接写情绪词，按需转译）：**

| 情绪 | 眼部 | 嘴唇/下颌 | 身体信号 |
|------|------|---------|---------| 
| 克制的悲 | gaze locked on fixed point, not blinking | lower lip pressed inward | one slow swallow |
| 即将哭泣 | eyes glistening, lower lashes wet | lips sealed but trembling | chin pulls down slightly |
| 交托/放松 | eyes close slowly | jaw releases | 深呼气肩膀落下半厘米 |
| 坚定 | eyes sharp, direct contact | lips press then release | chin lifts one degree |
| 隐秘认可 | gaze softens | lips press, not a smile | 指尖轻微收拢 |

### 快切组（Chorus / 高能段专用）

仅在音乐高能段使用，在 beat 序列中用【】标注：

```
[慢 beat 缓冲] →
【快切组，共Xs】
→ [部位A + 瞬间动作]
→ [部位B + 瞬间动作]
→ [部位C + 瞬间动作]
[慢 beat 缓冲 / 落点]
```

**四条规则：**
- 组内每个 beat 只写部位+动作，不写速度修饰
- **组内镜头运动必须锁定**，快切结束后才继续推
- 前后各留一个慢 beat 缓冲，不能直接进入或跳出快切组
- 组内部位必须交替，不能连续写同一身体部位

### 按音乐段落的 Beat 密度策略

| 音乐段落 | Beat 节奏 | 快切组 | 落点时长 |
|---------|---------|-------|---------| 
| Intro | 极慢，1个/2s | 无 | 长，2s+ |
| Verse | 匀速，1个/1s | 无 | 中，1.5s |
| Pre-chorus | 渐快，1个/0.8s | 可选，放末尾蓄力 | 短，悬而未发 |
| **Chorus** | **1个/0.3-0.4s** | **1-2组，核心** | **强，1.5-2s** |
| Bridge | 视情绪定 | 通常无 | 视情绪定 |
| Outro | 极慢，1个/2s+ | 无 | 极长，3s+ |

### 镜头层

**格式：** `镜头：[运动方式]，[触发条件]时锁定。`

镜头运动与 beat 序列**必须分行写**，禁止混在同一句话里。**快切组期间镜头运动锁定。**

**运镜决策：先问三个问题**

每个子镜头在确定运镜之前，先问：

**问题一：这一镜的情绪是收紧还是释放？**
- 收紧（克制、悬念、等待）→ 镜头抵抗情绪，反向运动或锁定
- 释放（爆发、到达、崩溃）→ 镜头顺情绪，加速或大幅位移

**问题二：这一镜和下一镜的关系是什么？**
- 同一场景延续 → 镜头运动方向为下一镜提供动势
- 场景切换 → 镜头运动在切点前反向收束
- 情绪对比 → 镜头语言故意与上一镜反向

**问题三：这一镜里有没有「空间矛盾」可以利用？**
- 主体距离感与心理距离感是否可以分裂？（Dolly Zoom）
- 焦点可以完成叙事转移？（Pull Focus）
- 有没有可以穿透的介质（玻璃/水面/镜面/烟雾）？

确定意图后，用物理语言描述运动：

```
❌ Slow Dolly In + Smooth + Cinematic + Intimate
✅ Slow Dolly In，从腰部高度推到面部，眼睛充满画面时锁定。
```

**运镜三级体系：**

**Level 1 — 基础动作：** Pan / Tilt / Zoom In/Out / Dolly In/Out / Truck / Crane Up/Down / Orbit / Arc Shot / Tracking / Static / Push In / Pull Out / Pedestal / Pull Focus

**Level 2 — 修饰词：**
- 速度：Smooth / Slow / Fast / Subtle / Gradual / Sudden
- 情绪：Cinematic / Aggressive / Dreamy / Intimate / Epic / Dynamic
- 风格：Handheld / Aerial / Dutch Angle / Gimbal / Steadicam / POV

**Level 3 — 组合（最多 2-3 个，用 + 连接）：** Orbit+Zoom In / Crane Up+Pan / Dolly Zoom / Tracking+Handheld / Dolly Back+Crane Up / Arc Shot+Zoom In

### 全局写作规则

**光影融入叙事：** 光影描述融入 beat 序列，不作为独立附件。写「金色侧光从窗缝斜切进来在@图片1肩线描出一道暖边」，不写「光影：金色侧光」。光影变化本身是 beat：「烛火被风骤然吹灭，整个空间陷入蓝调月光」。

**大气带入每镜：** 全片选定的大气效果写入每个 shot 风格行，可微调浓度，不换种类。

**一致性锁定：** 每个 shot 的 video_prompt 必须写入：
```
全片保持统一视觉风格，角色保持一致五官和服装，场景保持一致环境和光线，核心道具保持一致外观特征；
```

**道具连贯：** 已锁定道具首次出现必须写完整固定描述（颜色+型号/形态+材质），后续保持一致。

**空间连续性：** 同一场景连续 shot，video_prompt 首句（绑定之后）必须锚定主体在空间中的位置。

```
❌ "@图片1单手搭在方向盘上"
✅ "驾驶座视角，@图片1左手搭在方向盘十二点位"
```

**风格对齐：**

当 visual_identity 存在时：
- 机位选择优先使用 signature_shots 中声明的手法
- 色彩描述与 color_logic 一致
- 副歌/高潮段的景别、运镜速度、光影强度必须与主歌段有明显区分

当 visual_language 存在时：
- 画面质感与 texture 一致
- 构图体现 composition_tendency
- effect_signature 中声明的效果至少在全片 50%+ 的 shot 中出现

**收束（仅全片最后 shot 末尾）：**
```
[后期处理词 2-3个叠加]收尾，[张力宣言]。
后期处理词：暗角 / 胶片颗粒 / 色差 / 运动模糊 / 轻微过曝
```

### 反差 · Hero · 转场

**反差：** 全片至少 2 次明显反差：景别远↔近 / 动↔静 / 冷↔暖 / 封闭↔开阔

**反重复：**

相邻 shot 同满三项 = 无效重复：同场景 + 同情绪段位 + 同构图。有效推进至少一项：空间阈值 / 物件状态 / 人物关系 / 光线状态。

轮转表：正脸→背影/侧/局部 / 固定→运镜 / 暖→冷 / 近→全或特写 / 高强度→呼吸

**Hero Frame：** 全片 2-3 个，优先：开场第一帧、副歌开头、转折、结尾。判断法（满足 3+）：轮廓一眼能认 / 身体线条清楚 / 光源关系清楚 / 背景干净 / 缩略图成立 / 静音截图有情绪。

**跨场景转场桥接：**

跨场景切换时，前 shot 尾帧与后 shot 首帧必须有**至少一条视觉桥**（事件延续 / 光影变化 / 视觉母题 / 空间流动）。

**场景回访：** 再次进入已出现过的场景时，必须至少改变：光线状态 / 空间状态（物件位移/痕迹）/ 大气浓度。

---

## §5 Story 专属导演方法

### 单线特化 (sub_route=single)

- 不要把"发生了什么"平着拍完，优先找出这段**最贵的一帧**
- 一个 stage 里只挑**一个最值钱的动作**，不要什么都拍
- 如果是情绪段，不要只拍脸；给空间、手部、物件、门槛

**单线递进规则：**
- **开场段**：先给视觉悬念，不要立刻把全部信息说完
- **积累段**：用人物动作、空间阈值、物件状态推动
- **转折段**：必须通过可拍到的动作完成（打开纸袋 / 拿起钥匙 / 推门 / 搭上外套）
- **余波段**：让空间和身体状态保留变化后的后劲

**同一场景内的推进：** 必须至少推进一项：人物距离镜头远近 / 人物在空间中的位置 / 物件状态 / 光线方向或强度 / 前景遮挡或景深变化

### 双线特化 (sub_route=dual)

**双线对位方法：**
- 情绪对位：A线克制时B线释放，反之亦然
- 动作对位：A线的收束动作 → B线的展开动作
- 空间对位：A线封闭空间 → B线开阔空间
- 时间对位：A线现在 → B线过去/未来

**双线反重复：** 切换线时**必须**有至少一个明显视觉差异：景别变化 / 色温变化 / 光源方向变化

**双线转场：** 切线时的桥接优先：情绪对位 > 动作接力 > 光线过渡。

### Story 补充规则

**高级感来源：**
- **阈值**：门框、楼梯、车门、窗前、走廊转角
- **前景**：玻璃、水汽、帘子、肩膀
- **关系距离**：同框但不接触 / 接触但不对视
- **物件状态**：钥匙、手机、衣领、杯子、镜子
- **材质**：湿地面、旧木头、金属反光、布料褶皱

**身体姿态优先级：**
- 下巴抬起但肩膀压低
- 一手抓住衣领或包带
- 背靠空间边缘，重心偏到一侧
- 身体已经转走，视线还没离开
- 手停在物件上方而不是已经拿完

**表情与身体微状态（给 body: 标注用）：**

```
强势：chin raised, jaw set, heavy-lidded unyielding
忧郁：downcast eyes, soft unfocused, lips parted, brow furrowed
颓废：heavy-lidded, slow gaze, lips swollen, skin flushed
冷静：neutral, observing without engaging
脆弱：eyes wet, brows knitted, mouth trembling
神秘：slight closed-lip smile, gaze oblique
```

**风格禁止词：** story 专属禁止：`background dancer` / `dance routine` / `choreography`（除非 stage_plan 明确要求）

---

## §6 格式 + 示例

### video_prompt 格式

**标准模板：**

```
[资源绑定]
@图片1是角色X的参考形象，@图片2是场景「Y」的参考图，保持画面风格与参考图一致；
全片保持统一视觉风格，角色保持一致五官和服装，场景保持一致环境和光线，核心道具保持一致外观特征；

风格：[渲染风格/色彩基调/视觉调性，大气效果写在此行；摄影系时写相机型号]
场景：[此刻这个空间的真实样子——环境+光线+正在发生的动态元素（风/花/动物/自然现象/光变化等），写物理状态，不写形容词]

[Xs-Xs] 镜头1（景别 · 镜头运动）
[视觉元素A + 动作] →
[视觉元素B + 动作] →
落点：[定格画面——描述可拍的物理状态]
镜头：[运动方式]，[触发条件]时锁定。

[Xs-Xs] 镜头2（景别 · 镜头运动）
[视觉元素A + 动作] →
[视觉元素B + 动作] →
落点：[定格画面——描述可拍的物理状态]
镜头：[运动方式]，[触发条件]时锁定。

...（按实际子镜头数继续）

[收束（仅全片最后 shot）]
[后期处理词]收尾，[张力宣言]。

约束：avoid jitter，avoid identity drift，avoid bent limbs；角色运动与镜头运动全程分离；@图片N五官服装全镜一致。
```

**格式规则：**

1. **时间轴从 0 开始计数**，每个 SHOT 独立重置，与全片绝对时间无关。最后一镜的 end_time = SHOT duration，子镜头之间无间隙
2. **子镜头数量**与 shot 时长匹配（见 §4 Shot 组织表），不用公式计算
3. **每个子镜头**开头有 `[Xs-Xs] 镜头N（景别 · 镜头运动）` 标注行；相邻子镜头必须切换景别或机位
4. **镜头行与 beat 序列分行**，beat 序列用 `→` 连接，每个 `→` 只写一件事
5. **落点行**明确写可截图的定格画面，不写"静止"
6. **约束行**每 shot 末尾固定写入；特殊情况追加对应条目（见下）
7. 有效风格值存在→风格行写风格；缺失→只写光源+色调
8. 绑定后**必须**用 @图片N 指代角色；空镜不写角色 @图片N
9. 快切组仅在 Chorus/高能段使用；快切组期间镜头行写"镜头运动锁定"

**约束行按需追加：**
- 呼吸镜头（无角色）：`无角色面部入画`
- 镜像/双人：`禁止生成完整第二人脸，仅渲染[部位]局部反射`
- 特效场景：`禁止渲染角色身体透明或变形，用强光覆盖轮廓替代`

**English 变体：** 同结构，`@图片1 is reference for character X; @图片2 is reference for scene Y; keep visual style consistent with references;`，风格/场景/镜头内容全部英文。

### Case: Story MV 输出示例

> Verse 6s 细腻段 + Chorus 12s hero 段。仅供格式校准，禁止复制剧情。

```json
{
  "summarize": "黄昏海边的独角情感叙事。低饱和琥珀底调，薄海雾贯穿全片。从餐厅温馨记忆到栈道上信纸脱手，Ren在黄昏海边完成一次无声告别。",
  "shots": [
    {
      "shot_id": "Shot 2",
      "scene_name": "暖光小餐厅",
      "start_time": 10,
      "end_time": 16,
      "duration": 6,
      "description": "Verse 回忆段：餐桌上的温馨碎片，蛋糕递送与视线交汇",
      "video_prompt": "@图片1是角色Ren的参考形象，@图片2是场景「暖光小餐厅」的参考图，保持画面风格与参考图一致；\n全片保持统一视觉风格，角色保持一致五官和服装，场景保持一致环境和光线，核心道具保持一致外观特征；\n\n风格：ARRI Alexa Mini LF 85mm，Kodak 5219 胶片模拟，subtle film grain，爱迪生灯泡暖黄单光源，薄海雾从窗缝渗入室内形成轻柔漫射。\n场景：暖光小餐厅角落，爱迪生灯泡垂下暖黄光池，旧木桌上摆着两杯红酒和半块奶油蛋糕，蛋糕盘边一只小蚂蚁正努力搬走一粒糖渣，窗台上一只灰鸽子歪着头往里看。\n\n[0-2s] 镜头1（俯拍 · Static）\n桌面正上方俯瞰——两双手在盘子和酒杯之间，蛋糕碎屑散落亚麻桌布 →\n那只小蚂蚁绕过一颗面包屑继续搬它的糖渣，爱迪生灯泡暖光在木桌面铺出金色圆池 →\n落点：蚂蚁停在糖渣旁，桌面金色光池边缘清晰，两双手指节压在桌布纹理上。\n镜头：锁定俯拍角度不动——静止本身制造观察感，不需要运动。\n\n[2-4s] 镜头2（近景 · Pull Focus）\n对面伸过来一只手，指尖沾着奶油，叉尖挑起一块蛋糕向@图片1方向送去 →\n@图片1下意识伸手够桌上纸巾，对面比她快一步抽出来递过去，两手指尖在纸巾边缘短暂接触 →\n落点：接触点皮肤轻微压白，浅景深将背景压成失焦的暖色，纸巾还悬在两人之间未落定。\n镜头：Pull Focus 从对面手腕切换到接触点，镜头本身不动——焦点落下那一帧即是重量。\n\n[4-6s] 镜头3（全景 · Slow Pull Out）\n窗台上的鸽子被室内的笑声惊得骤然扑棱飞起 →\n从窗外往里拍，隔着起雾的玻璃两人的笑容柔化成失焦的蜜色块 →\n落点：窗面上一颗冷凝水珠缓缓滑落，鸽子背影在画面右上角消失，室内暖光块压稳画面中央。\n镜头：Slow Pull Out 从窗台向外缓退，鸽子飞走时收住——情绪收紧，镜头拉开距离强化旁观感。\n\n约束：avoid jitter，avoid identity drift，avoid bent limbs；角色运动与镜头运动全程分离；@图片1五官服装全镜一致。",
      "character_name": "Ren"
    },
    {
      "shot_id": "Shot 4",
      "scene_name": "海边栈道",
      "start_time": 24,
      "end_time": 36,
      "duration": 12,
      "description": "Chorus hero：栈道尽头信纸脱手，蓄力→快切爆发→归于平静",
      "video_prompt": "@图片1是角色Ren的参考形象，@图片2是场景「海边栈道」的参考图，保持画面风格与参考图一致；\n全片保持统一视觉风格，角色保持一致五官和服装，场景保持一致环境和光线，核心道具保持一致外观特征；\n\n风格：ARRI Alexa Mini LF 35mm，Kodak 5219 胶片模拟，subtle film grain，落日强侧逆光，薄海雾浓度加深。\n场景：黄昏海边木栈道尽头，远处海天交界线被落日烧成金红，栏杆上褪色红丝带被海风扯直，一只海鸥停在栏杆顶端梳理羽毛。\n\n[0-3s] 镜头1（微距 · Static）\n栈道木板缝隙中一只寄居蟹骤然缩回壳内，木板纹理上的盐渍结晶在逆光中闪烁 →\n@图片1的赤足脚趾在木板边缘缓缓收紧，趾甲压白一圈 →\n落点：脚趾压白收住，木板纹理和盐渍结晶清晰，寄居蟹壳口紧闭。\n镜头：锁定微距不动——让细节本身传达张力，不需要运动。\n\n[3-6s] 镜头2（近景 · Slow Dolly In）\n@图片1肩线微微下沉，像是长时间忍住的呼气终于松开 →\ngaze 从紧握的信纸边缘开始抬，抬到一半停住两拍(body: eyes glistening, lower lashes wet, lips sealed) →\n手指骤然松开——信纸脱手的瞬间被海风撕裂为数十片碎片 →\n落点：碎片在画面前方乱飞，@图片1手掌朝上展开，指尖还在微颤，逆光将她的轮廓烧成金边。\n镜头：Slow Dolly In 从胸口缓推到手掌，信纸脱手时锁定——顺情绪加速释放。\n\n[6-9s] 镜头3（近景 · 镜头运动锁定）\n栏杆上的海鸥被碎片惊得炸飞，翅膀扇动时羽毛骨清晰 →\n【快切组，共1.5s】\n→ @图片1手指反握成拳，五指一根一根扣紧\n→ 碎片在逆光中翻转，内侧墨迹在阳光下闪过\n→ 海鸥身影在金红天空中拉出一道弧线消失\n落点：@图片1的拳头收住，指节压白，落日逆光在拳背描出一道金边。\n镜头：快切组期间镜头运动锁定；落点帧完成后 Tilt Up 抬起，为下一镜切点提供向上动势。\n\n[9-12s] 镜头4（全景 · Dolly Back+Crane Up）\n@图片1独立于栈道尽头，海风将头发和红丝带同时向一侧吹起 →\n落日色温骤然加深一度，整片天空从金红变为暗橙 →\n落点：@图片1剪影在画面中央，握紧的拳头轮廓可见，身后暗橙天空与海面连成一片。\n镜头：Dolly Back+Crane Up，剪影在退后中反而压住画面中央——用空间矛盾制造"渺小却在此刻"的感觉。\n\n暗角+胶片颗粒+色差收尾，海雾从两侧涌来将栈道吞没，像一页被合上的书。\n\n约束：avoid jitter，avoid identity drift，avoid bent limbs；角色运动与镜头运动全程分离；@图片1五官服装全镜一致。",
      "character_name": "Ren"
    }
  ]
}
```

---

## §7 收尾验证

### 禁止词

```
dramatic / epic / breathtaking / stunning / gorgeous / beautiful / magical
cinematic lighting（必须写具体光源）
ethereal glow / glowing particles / floating orbs / magical particles
neon / 霓虹（用 colored gel light / colored LED strip / colored storefront sign 替代）
ambient warm light / warm light + cool light（无主次）
background dancer / dance routine / choreography（除非 stage_plan 明确要求）
```

运镜禁止：缓慢移动 / 镜头变化 / 画面切换 → 用三级精确术语
情感禁止：sad expression / happy face → 写可拍物理状态
物理矛盾禁止：wide angle + shallow DoF / long shot + extreme bokeh / close-up + wide angle
特效禁止：禁止描述角色身体半透明或溶解。"融入背景"用强光从外部包裹轮廓替代。

### 最终检查

```
□ 字段完整（8字段），时间值整数，时间轴连续，每 shot 4-15s
□ video_prompt 子镜头时间轴从 0 开始计数，每 shot 独立重置，最后一镜 end_time = SHOT duration
□ 子镜头数量与 shot 时长匹配（4-5s:2-3镜 / 6-8s:3-4镜 / 9-12s:4-5镜 / 13-15s:5-6镜）
□ 每个子镜头开头有 [Xs-Xs] 镜头N（景别 · 镜头运动）标注行
□ 相邻子镜头景别或机位已切换，无连续两镜同景别同机位
□ beat 序列用 → 连接，每个 → 只写一件事
□ 身体动作写传导顺序（肩→躯干→头→发丝），不写结果
□ 眼神有轨迹（从哪→到哪→停在哪），不写状态词
□ 每个 SHOT 至少一次速度突变（骤然/snap/猛然），分布在整个 SHOT 内
□ 附属物有惯性延迟（发丝比头慢半拍/裙摆还荡了一下）
□ 落点是定格画面，描述可拍的物理状态，不写"静止"
□ 镜头行与 beat 序列分行，先问三个问题再决定运镜
□ 快切组仅在 Chorus/高能段使用，组内镜头运动锁定，前后有慢 beat 缓冲
□ 约束行每 shot 末尾写入，特殊情况追加对应条目
□ @图片N 先角色后场景，每 shot 从 1 重新开始
□ 一致性锁定文本每 shot 写入
□ 风格行写渲染/色调/大气；摄影系时包含相机型号；场景行写物理状态无形容词
□ 无禁止词，无物理矛盾，无身体透明/溶解描述
□ 道具首次出现写完整固定描述
□ 同场景连续 shot 有空间锚点
□ 全片最后 shot 有收束句
□ 至少 2 次反差，2-3 个 hero frame，Shot 1 反直觉开场
□ 跨场景有视觉桥，场景回访有变化
□ character_name 非空 → 不得为空镜
```
